﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ButtonManager : MonoBehaviour
{
    public static int StageCount = 0;
    public TMP_Text inspector_Count;
    // yes 버튼 동작 함수
    public void YesBtn()
    {
        Binary_Main.instance.answer += Binary_Main.instance.numberCardList[StageCount][0];
        if (++StageCount == 6)
        {
            GameObject.Find("Canvas").transform.Find("Step2").gameObject.SetActive(false);
            GameObject.Find("Canvas").transform.Find("Step3").gameObject.SetActive(true);
        }
        else
        {
            Step2_Active();
        }
        inspector_Count.text = string.Format("({0}/6)", StageCount+1);
    }

    // no 버튼 동작 함수
    public void NoBtn()
    {
        if (++StageCount == 6)
        {
            GameObject.Find("Canvas").transform.Find("Step2").gameObject.SetActive(false);
            GameObject.Find("Canvas").transform.Find("Step3").gameObject.SetActive(true);
        }
        else
        {
            Step2_Active();
        }
        inspector_Count.text = string.Format("({0}/6)", StageCount+1);
    }
    
    public void Step2_Active()
    {
        GameObject.Find("Canvas").transform.Find("Step2").gameObject.SetActive(false);
        GameObject.Find("Canvas").transform.Find("Step2").gameObject.SetActive(true);
    }

    public void Last_Result()
    {
        GameObject.Find("Result_flag").GetComponent<Image>().color = Color.white;
        GameObject.Find("Result_flag").transform.GetChild(0).GetComponent<TMP_Text>().text = Binary_Main.instance.answer.ToString();
        GameObject.Find("Last_Text").GetComponent<TMP_Text>().text = " 짠~";
        GameObject.Find("Result_flag").GetComponent<Outline>().effectColor = new Color(0, 0, 0, 255);
    }
}
