﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Binary_Main : MonoBehaviour
{
    public static Binary_Main instance;
    public int answer = 0;

    // 기본 카드들
    private int[,] numberCard = new int[6, 33] {
        {1, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59, 61, 63},
        {2, 2, 3, 6, 7, 10, 11, 14, 15, 18, 19, 22, 23, 26, 27, 30, 31, 34, 35, 38, 39, 42, 43, 46, 47, 50, 51, 54, 55, 58, 59, 62, 63},
        {4, 4, 5, 6, 7, 12, 13, 14, 15, 20, 21, 22, 23, 28, 29, 30, 31, 36, 37, 38, 39, 44, 45, 46, 47, 52, 53, 54, 55, 60, 61, 62, 63},
        {8, 8, 9, 10, 11, 12, 13, 14, 15, 24, 25, 26, 27, 28, 29, 30, 31, 40, 41, 42, 43, 44, 45, 46, 47, 56, 57, 58, 59, 60, 61, 62, 63},
        {16, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63},
        {32, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63}
    };

    // 셔플을 위해 배열 내용을 복사할 리스트
    public List<List<int>> numberCardList;


    void Awake()
    {
        if(!instance)
        {
            instance = this;
        }
        // 리스트 초기화
        numberCardList = new List<List<int>>();

        for(int i = 0; i < numberCard.GetLength(0); i++) //  6
        {
            // 2차원 리스트중 1차원? 초기화([동][호] 라면, 0동을 초기화 한것)
            numberCardList.Add(new List<int>());

            // 호 부분 내용을 채워 나감
            for (int j = 0; j < numberCard.GetLength(1); j++) // 32
            {
                numberCardList[i].Add(numberCard[i,j]);
            }
        }

        // 1차원 셔플
        ShuffleNumberCard<List<int>>(numberCardList, 0);

        //// 2차원 셔플
        //for (int i = 0; i < numberCardList.Count; i++)
        //{
        //    ShuffleNumberCard<int>(numberCardList[i], 1);
        //}
    }

    // Start is called before the first frame update
    void Start()
    {
       
    }


    // 리스트 셔플
    public void ShuffleNumberCard<T>(List<T> list, int startNum)
    {
        int random1;
        int random2;

        T tmp;

        for (int index = startNum; index < list.Count; ++index)
        {
            random1 = Random.Range(startNum, list.Count);
            random2 = Random.Range(startNum, list.Count);

            tmp = list[random1];
            list[random1] = list[random2];
            list[random2] = tmp;
        }
    }

    // 각 리스트 요소 받아오는 방법
    public void getList()
    {
        for(int i = 0; i < numberCardList.Count; i++)
        {
            for(int j = 1; i < numberCardList[i].Count; j++)
            {
                print(numberCardList[i][j]);

                // 해당 카드가 yes이면
                answer += numberCardList[i][0]; // 해당 카드의 키(1 or 2 or 4 or 8 or 16 or 32)를 더해줌
            }
        }
    }
}
