﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class B_NextBtn : MonoBehaviour
{
    public string nowStage;
    public int index;



    public void Next_()
    {
        nowStage = GameObject.FindWithTag("Step").name;
        string[] splitStr = nowStage.Split('p');
        index = int.Parse(splitStr[1]);
        // print("Step" + (index + 1).ToString());
        if (nowStage == "Step1") // end
        {
            GameObject.Find("Canvas").transform.Find("B_Next_btn").gameObject.SetActive(false);
        }
        if (nowStage == "Step" + index.ToString())
        {
            try
            {
                GameObject.Find("Canvas").transform.Find("Step" + index.ToString()).gameObject.SetActive(false);
                //print("Step" + index.ToString());
                GameObject.Find("Canvas").transform.Find("Step" + (index + 1).ToString()).gameObject.SetActive(true);
                //print("Step" + (index + 1).ToString());
            }
            catch
            {
                print("error");
            }
        }

    }
}

