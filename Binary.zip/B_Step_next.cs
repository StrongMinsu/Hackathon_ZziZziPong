﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using TMPro;

//   print("＃＆＠§※☆★○●◎◇◆□■△▲♤♠♡♥♧♣⊙◈▣☏◐◑▒▤▤☜♬♪♨");
public class B_Step_next : MonoBehaviour
{

    static public List<GameObject> iconNumSlot;
    public GameObject iconsNum_Prefab;
    private int SlotCount = 33;
    private bool Initial_check;

    private void Start()
    {
        iconNumSlot = new List<GameObject>();
        SlotCreate(iconNumSlot, SlotCount);
        Initial_check = true;
    }
    private void OnEnable()
    {
        if (Initial_check)
        {
            SlotChange(iconNumSlot);
        }
    }

    public void SlotCreate(List<GameObject> obj, int num)
    {
        
        for (int i = 0; i < num; i++)
        {
           
            obj.Add(Instantiate(iconsNum_Prefab));
            obj[i].name = Binary_Main.instance.numberCardList[ButtonManager.StageCount][i].ToString();
            obj[i].transform.SetParent(gameObject.transform);
            obj[i].transform.SetAsLastSibling();
            
            obj[i].transform.Find("iconText").GetComponent<TMP_Text>().text = Binary_Main.instance.numberCardList[ButtonManager.StageCount][i].ToString();
            if (i == 0)
            {
                obj[i].SetActive(false);
            }
        }
    }
    public void SlotChange(List<GameObject> obj)
    {
        int index = 0;
        foreach(var obj_ in obj)
        {
            obj_.SetActive(true);
            if (obj_.activeSelf)
            {
                obj_.name = Binary_Main.instance.numberCardList[ButtonManager.StageCount][index].ToString();
                //obj[i].transform.SetParent(gameObject.transform);
                //obj[i].transform.SetAsLastSibling();

                obj_.transform.Find("iconText").GetComponent<TMP_Text>().text = Binary_Main.instance.numberCardList[ButtonManager.StageCount][index].ToString();

                if (index == 0)
                {
                    obj_.SetActive(false);
                }
            }
            index++;
        }
    }
}
