﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Icon
{
    public int iconNum; //아이콘 넘버
    public Sprite iconIMG;//아이콘 이미지
    //public string iconText;// 아이콘 기호

    public Icon(int _iconNum, Sprite _iconIMG )
    {
        iconNum = _iconNum;
       // iconText = _iconText;
        iconIMG = _iconIMG;
    }
}
