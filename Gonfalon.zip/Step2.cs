﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using TMPro;

//   print("＃＆＠§※☆★○●◎◇◆□■△▲♤♠♡♥♧♣⊙◈▣☏◐◑▒▤▤☜♬♪♨");
public class Step2: MonoBehaviour
{
    static public List<GameObject> iconNumSlot;
    public GameObject iconsNum_Prefab;
    public int SlotCount = 100;

    private void OnEnable() // 아이콘 재배치
    {
        iconNumSlot = new List<GameObject>();
        SlotCreate(iconNumSlot, SlotCount);
    }
  
    
public void SlotCreate(List<GameObject> obj, int num)
    {
        for (int i = 0; i < num; i++)
        {
            obj.Add(Instantiate(iconsNum_Prefab));
            obj[i].name = ""+i;
            obj[i].transform.SetParent(gameObject.transform);
            obj[i].transform.SetAsLastSibling();
            obj[i].transform.Find("iconText").GetComponent<TMP_Text>().text = i.ToString();
            obj[i].SetActive(true);
        }        
    }
}
