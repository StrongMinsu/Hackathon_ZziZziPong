﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class Scene_Mng : MonoBehaviour
{
    public void Load_Exclusion_()
    {
        SoundManager.instance.AudioStop();
        SoundManager.instance.PlaySound("Btn_Sound");
        SoundManager.instance.PlaySound("StartMagic");
        SceneManager.LoadScene("Exclusion_");
    }
    public void Load_Binary_()
    {
        SoundManager.instance.AudioStop();
        SoundManager.instance.PlaySound("Btn_Sound");
        SoundManager.instance.PlaySound("StartMagic");
        SceneManager.LoadScene("Binary_");
    }
    public void Load_Gonflaon_()
    {
        SoundManager.instance.AudioStop();
        SoundManager.instance.PlaySound("Btn_Sound");
        SoundManager.instance.PlaySound("StartMagic");
        SceneManager.LoadScene("Gonfalon_");
    }
    public void Load_Title()
    {
        Coroutine_Mng.instance.coroutine_Active = false;
        Coroutine_Mng.instance.StopCoroutine("FadeOut");

        SoundManager.instance.AudioStop();
        SoundManager.instance.PlaySound("Btn_Sound");
        SoundManager.instance.PlaySound("GoHome");
        SoundManager.instance.PlaySound_Loop("TitleSound");
        SceneManager.LoadScene("Title_Scene");
    }
}
