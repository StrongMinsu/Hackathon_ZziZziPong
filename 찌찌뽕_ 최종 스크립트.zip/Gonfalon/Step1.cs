﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using TMPro;

//   print("＃＆＠§※☆★○●◎◇◆□■△▲♤♠♡♥♧♣⊙◈▣☏◐◑▒▤▤☜♬♪♨");
public class Step1: MonoBehaviour
{

    static public List<GameObject> iconNumSlot;
    public GameObject iconsNum_Prefab;
    public int SlotCount = 100;

    private void Start()
    {
        iconNumSlot = new List<GameObject>();
        SlotCreate(iconNumSlot, SlotCount);
    }
    private void OnEnable() // 아이콘 재배치
    {
        GameObject.Find("Canvas").transform.Find("Step2").gameObject.SetActive(false);
        GameObject.Find("Canvas").transform.Find("Step3").gameObject.SetActive(false);
        GameObject.Find("Canvas").transform.Find("Step4").gameObject.SetActive(false);
    }
  
    
public void SlotCreate(List<GameObject> obj, int num)
    {
        for (int i = 0; i < num; i++)
        {
            obj.Add(Instantiate(iconsNum_Prefab));
            obj[i].name = ""+i;
            obj[i].transform.SetParent(gameObject.transform);
            obj[i].transform.SetAsLastSibling();
            if(i>=0 && i<10)
            {
                obj[i].SetActive(false);
            }
            obj[i].transform.Find("iconText").GetComponent<TMP_Text>().text = i.ToString();
           // obj[i].SetActive(true);
        }        
    }
}
