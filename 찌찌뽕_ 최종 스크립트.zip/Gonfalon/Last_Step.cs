﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class Last_Step : MonoBehaviour
{
   public void CheckOut()
    {
        Image result_flag = gameObject.transform.Find("Result_flag").GetComponent<Image>();
        result_flag.sprite = Step3.GameManager.icons[Step3.GameManager.Target].iconIMG;
        Coroutine_Mng.instance.StartCoroutine("FadeOut", result_flag);

        gameObject.transform.Find("Last_Text").GetComponent<TMP_Text>().text = " 짜잔~";
        gameObject.transform.Find("Result_flag").GetComponent<Outline>().effectColor = new Color(0, 0, 0, 255);

        
    }


}
