﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using TMPro;

//   print("＃＆＠§※☆★○●◎◇◆□■△▲♤♠♡♥♧♣⊙◈▣☏◐◑▒▤▤☜♬♪♨");
public class Step3 : MonoBehaviour
{
    public static Step3 GameManager;
    public int Target = 0;
    object[] files;

    static public List<GameObject> iconSlot;
    public List<Icon> icons = new List<Icon>();
    public GameObject iconsPrefab;
    public bool Initial_check = false;

    private void Awake()
    {
        if (!GameManager)
        {
            GameManager = this;
        }
    }
    private void Start()
    {
        iconSlot = new List<GameObject>();
        SlotCreate(iconSlot, 100);

        files = Resources.LoadAll<Sprite>("iconImage");
        IMG_initialized();
        RandomEmoticonFunc();
    }
  
    public void IMG_initialized()
    {
        for (int img = 0; img < files.Length; img++)
        {
            Add(img);
        }
        void Add(int iconNum)
        {
            icons.Add(new Icon(iconNum, Resources.Load<Sprite>("iconImage/" + iconNum.ToString())));
            
            //Resources - iconImage 폴더의 iconText와 일치하는 그림을 불러옴 
        }
        
    }
    
    //foreach (var i in icons)
      //      print("호잇" + i.iconIMG.name);

public void SlotCreate(List<GameObject> obj, int num)
    {
        for (int i = 0; i < num; i++)
        {
            obj.Add(Instantiate(iconsPrefab));
            obj[i].name = ""+i;
            obj[i].transform.SetParent(gameObject.transform);
            obj[i].transform.SetAsLastSibling();
            obj[i].SetActive(true);
        }        
    }

    void RandomEmoticonFunc()
    {
        Target = Random.Range(0, files.Length); // 랜덤 이모티콘을 하나 정하고
        for (int i = 0; i < 100; i++)
        {
            int random = Random.Range(0, files.Length);

            iconSlot[i].transform.Find("iconText").GetComponent<TMP_Text>().text = i.ToString();
            if (i % 9 == 0 && i < 90)
            {
                iconSlot[i].GetComponent<Image>().sprite = icons[Target].iconIMG; //9의 배수인 슬롯의 이모티콘을 동일하게 변경하고
            }
            else
            {
                iconSlot[i].GetComponent<Image>().sprite = icons[random].iconIMG; // 아니면 그냥 줫대로
            }
        }
    }
}
