﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Coroutine_Mng : MonoBehaviour
{
    public static Coroutine_Mng instance;
    public bool coroutine_Active = false;
    public bool animation_Active = false;
    private List<Sprite> title_img = new List<Sprite>();
    private void Awake()
    {
        if(!instance)
        {
            instance = this;
        }
    }

    IEnumerator FadeOut(Image Box)
    {
        if (coroutine_Active == false)
        {
            coroutine_Active = true;
            Box.color = new Color(Box.color.r, Box.color.g, Box.color.b);
            SoundManager.instance.PlaySound("ResultSound");
            
            yield return new WaitForSeconds(1f);
            while (Box.color.r < 255f)
            {
                Box.color = new Color(Box.color.r + Time.deltaTime, Box.color.g + Time.deltaTime, Box.color.b + Time.deltaTime);
                yield return new WaitForSeconds(0.05f);
            }
        }
    }


}
