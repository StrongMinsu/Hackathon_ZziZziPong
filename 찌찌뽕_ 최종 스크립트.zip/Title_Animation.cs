﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Title_Animation : MonoBehaviour
{
    private Image title_img;
    private void Start()
    {
        title_img = gameObject.GetComponent<Image>();
        StartCoroutine(Title_Ani(title_img));


    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
    }

    IEnumerator Title_Ani(Image title)
    {
        Sprite[] temp = Resources.LoadAll<Sprite>("Title_Animation"); //Resources - Sounds 폴더 안에 있는 모든 뮤직리스트 가져옴.

        while (true)
        {
            foreach (var img in temp)
            {
                title_img.sprite = img;
                yield return new WaitForSeconds(0.1f);
            }
        }
    }

}
