﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class B_NextBtn : MonoBehaviour
{
    public string nowStage;
    public int index;



    public void Next_()
    {
        SoundManager.instance.PlaySound("ArrowBtn");
        nowStage = GameObject.FindWithTag("Step_").name;
        string[] splitStr = nowStage.Split('_');
        index = int.Parse(splitStr[1]);
        // print("Step" + (index + 1).ToString());
        if (nowStage == "Step_1") // end
        {
            GameObject.Find("Canvas").transform.Find("B_Next_btn").gameObject.SetActive(false);
        }
        if (nowStage == "Step_" + index.ToString())
        {
            try
            {
                GameObject.Find("Canvas").transform.Find("Step_" + index.ToString()).gameObject.SetActive(false);
                //print("Step" + index.ToString());
                GameObject.Find("Canvas").transform.Find("Step_" + (index + 1).ToString()).gameObject.SetActive(true);
                //print("Step" + (index + 1).ToString());
            }
            catch
            {
                print("error");
            }
        }

    }
    
}

