﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Title_Manager : MonoBehaviour
{
    public static Title_Manager instance;

    private void Awake()
    {
        if (!instance)
        {
            instance = this;
        }
    }
    public void Title_Music()
    {
        SoundManager.instance.PlaySound_Loop("TitleSound");
    }

}
