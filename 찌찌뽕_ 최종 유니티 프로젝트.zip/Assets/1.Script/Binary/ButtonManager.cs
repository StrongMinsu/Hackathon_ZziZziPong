﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ButtonManager : MonoBehaviour
{
    public static int StageCount = 0;
    public TMP_Text inspector_Count;
    // yes 버튼 동작 함수
    public void YesBtn()
    {
        SoundManager.instance.PlaySound("Binary_Yes");
        Binary_Main.instance.answer += Binary_Main.instance.numberCardList[StageCount][0];
        if (++StageCount == 6)
        {
            GameObject.Find("Canvas").transform.Find("Step_2").gameObject.SetActive(false);
            GameObject.Find("Canvas").transform.Find("Step_3").gameObject.SetActive(true);
        }
        else
        {
            Step2_Active();
        }
        inspector_Count.text = string.Format("({0}/6)", StageCount+1);
    }

    // no 버튼 동작 함수
    public void NoBtn()
    {
        SoundManager.instance.PlaySound("Binary_No");
        if (++StageCount == 6)
        {
            GameObject.Find("Canvas").transform.Find("Step_2").gameObject.SetActive(false);
            GameObject.Find("Canvas").transform.Find("Step_3").gameObject.SetActive(true);
        }
        else
        {
            Step2_Active();
        }
        inspector_Count.text = string.Format("({0}/6)", StageCount+1);
    }
    
    public void Step2_Active()
    {
        GameObject.Find("Canvas").transform.Find("Step_2").gameObject.SetActive(false);
        GameObject.Find("Canvas").transform.Find("Step_2").gameObject.SetActive(true);
    }

    public void Last_Result()
    {
        Image result_flag = GameObject.Find("Result_flag").GetComponent<Image>();
        Coroutine_Mng.instance.StartCoroutine("FadeOut", result_flag);

        GameObject.Find("Result_flag").transform.GetChild(0).GetComponent<TMP_Text>().text = Binary_Main.instance.answer.ToString();
        GameObject.Find("Last_Text").GetComponent<TMP_Text>().text = " 짠~";
        GameObject.Find("Result_flag").GetComponent<Outline>().effectColor = new Color(0, 0, 0, 255);
    }
}
