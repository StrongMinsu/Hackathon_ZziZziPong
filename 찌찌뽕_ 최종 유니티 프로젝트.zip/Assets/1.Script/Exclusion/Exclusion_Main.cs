﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using TMPro;


public class Exclusion_Main : MonoBehaviour
{
    //private string testString = "212"; // 나중에 inputField로 받음
    private int answer = 0;
    public static TMP_InputField InputText;

    // Start is called before the first frame update
    void Start()
    {
        InputText = gameObject.transform.Find("KeyPad").GetChild(1).GetComponent<TMP_InputField>();
        
        Next_Text.StepCount = 0;
        Next_Text.input_check = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private int checkNum(int n)
    {
        int num = 0; // 212 라면 2 + 1 + 2 를 저장하는 변수

        int h = 0;  // 100의 자리 숫자 (2)
        int t = 0;  // 10의 자리 숫자 (1)
        int o = 0;  // 1의 자리 숫자(2)

        h = (int)Math.Truncate((double)(n / 100));
        num += h;

        t = (int)Math.Truncate((double)((n - h * 100) / 10));
        num += t;

        o = (int)Math.Truncate((double)((n - h * 100 - t * 10) / 1));
        num += o;

        //print(++count + " : " + num);

        if (num > 9)
        {
            return checkNum(num);
        }
        else if(num == 9)
        {
            return num;
        }
        else
        {
            return 9 - num;
        }
    }

    
    // 3자리 숫자 입력 버튼 동작 함수
    public void InputBtn()
    {
        answer = checkNum(int.Parse(InputText.text));
        Last_Result();

    }

    public void Last_Result()
    {
        Image result_flag = GameObject.Find("Result_flag").GetComponent<Image>();
        Coroutine_Mng.instance.StartCoroutine("FadeOut", result_flag);
        GameObject.Find("Result_flag").transform.GetChild(0).GetComponent<TMP_Text>().text = answer.ToString();
        GameObject.Find("Last_Text").GetComponent<TMP_Text>().text = " 찌찌뽕~";
        GameObject.Find("Result_flag").GetComponent<Outline>().effectColor = new Color(0, 0, 0, 255);
    }
}
