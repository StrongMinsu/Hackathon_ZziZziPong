﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Next_Text : MonoBehaviour
{
    public static int StepCount = 0;
    private TMP_Text Notice_;
    public static bool input_check=false;
    Sprite[] book;

    public void Next_TextStage()
    {
        book = Resources.LoadAll<Sprite>("Books");
        SoundManager.instance.PlaySound("ArrowBtn");
        if (Exclusion_Main.InputText.text.Length == 3)
        {
            input_check = true;
        }
        if (StepCount != 3)
        {
            StepCount++;
        }
         
        Notice_ = GameObject.Find("Notice").transform.GetChild(0).GetComponent<TMP_Text>();
 
        switch (StepCount)
        {
            case 0:
                Notice_.text = "\"1010~9999\" 사이의 비밀번호를 마음속으로 생각해요.";
                GameObject.Find("Canvas").transform.Find("Book_Img").GetComponent<Image>().sprite = book[0];
                break;

            case 1:
                Notice_.text = "비밀번호에서 각 자리수를 더한 총합을 빼세요.";
                GameObject.Find("Canvas").transform.Find("E_Back_btn").gameObject.SetActive(true);
                GameObject.Find("Canvas").transform.Find("Book_Img").GetComponent<Image>().sprite = book[1];
                break;
            case 2:
                Notice_.text = "결과값에서 한자리를 제외한 나머지 숫자를 무작위로 조합해 알려주세요!";
                GameObject.Find("Canvas").transform.Find("KeyPad").gameObject.SetActive(true);
                GameObject.Find("Canvas").transform.Find("Book_Img").gameObject.SetActive(false);
                break;
            case 3:
                if (input_check)//세자리 숫자 전부 입력이 이루어졌을 때만
                {
                    GameObject.Find("Canvas").transform.Find("Step1").gameObject.SetActive(false);
                    GameObject.Find("Canvas").transform.Find("KeyPad").gameObject.SetActive(false);
                    GameObject.Find("Canvas").transform.Find("Step2").gameObject.SetActive(true);
                    GameObject.Find("Canvas").transform.Find("E_Next_btn").gameObject.SetActive(false);
                }
                break;
        }
    }
    public void Back_TextStage()
    {
        SoundManager.instance.PlaySound("ArrowBtn");
        if (StepCount != 0)
        {
            StepCount--;
        }

        Notice_ = GameObject.Find("Canvas").transform.Find("Step1").transform.Find("Notice").transform.GetChild(0).GetComponent<TMP_Text>();

        switch (StepCount)
        {
            case 0:
                Notice_.text = "\"1010~9999\" 사이의 비밀번호를 마음속으로 생각해요.";
                GameObject.Find("Canvas").transform.Find("E_Back_btn").gameObject.SetActive(false);
                GameObject.Find("Canvas").transform.Find("Book_Img").GetComponent<Image>().sprite = book[0];
                break;

            case 1:
                GameObject.Find("Canvas").transform.Find("Book_Img").gameObject.SetActive(true);
                Notice_.text = "비밀번호에서 각 자리수를 더한 총합을 빼세요.";
                GameObject.Find("Canvas").transform.Find("KeyPad").gameObject.SetActive(false);
                break;
            case 2:
                Notice_.text = "결과값에서 한자리를 제외한 나머지 숫자를 무작위로 조합해 알려주세요!";

                GameObject.Find("Canvas").transform.Find("KeyPad").gameObject.SetActive(true);
                GameObject.Find("Canvas").transform.Find("Step2").gameObject.SetActive(false);
                GameObject.Find("Canvas").transform.Find("Step1").gameObject.SetActive(true);
                GameObject.Find("Canvas").transform.Find("E_Next_btn").gameObject.SetActive(true);
                break;

        }
    }
}
