﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using TMPro;
using UnityEngine.EventSystems;

//   print("＃＆＠§※☆★○●◎◇◆□■△▲♤♠♡♥♧♣⊙◈▣☏◐◑▒▤▤☜♬♪♨");
public class KeyPad : MonoBehaviour
{

    static public List<GameObject> keySlot;
    public GameObject keyPad_Prefab;
    private int keyCount = 12;
    private string pad_; // 패드 키값 받아올려고

    private void Start()
    {
        keySlot = new List<GameObject>();
        GameObject[] steps = GameObject.FindGameObjectsWithTag("Step");
        foreach (var obj in steps)
        {
            if (obj != steps[0])
            {
                obj.SetActive(false);
            }
        }
        SlotCreate(keySlot, keyCount);
    }

    public void SlotCreate(List<GameObject> obj, int num)
    {
        for (int i = 0; i < num; i++)
        {
            obj.Add(Instantiate(keyPad_Prefab));
            obj[i].name = "key" + i;
            obj[i].transform.SetParent(gameObject.transform);
            obj[i].transform.SetAsLastSibling();
            obj[i].transform.Find("iconText").GetComponent<TMP_Text>().text = i.ToString();
            // obj[i].SetActive(true);
        }
        obj[10].GetComponent<Image>().color = Color.clear; // 0번을 밀어주기 위함
        obj[10].transform.GetChild(0).GetComponent<TMP_Text>().color = Color.clear;
        obj[0].transform.SetAsLastSibling();

        obj[11].transform.SetAsLastSibling(); // 지우기 버튼
        obj[11].name = "delete_btn";
        obj[11].transform.Find("iconText").GetComponent<TMP_Text>().text = "";
        obj[11].transform.Find("delete_img").gameObject.SetActive(true);
    }

    public void KeyClick()
    {
        SoundManager.instance.PlaySound("Dial_Sound");
        pad_ = EventSystem.current.currentSelectedGameObject.name;
        string[] pad_num = pad_.Split('y');


        //EventSystem.current.currentSelectedGameObject.transform.Find("iconText").GetComponent<TMP_Text>().color= new Color(63, 58, 58, 255); //키 프레스 색깔
        
        if (pad_!="delete_btn")
        {
            if (Exclusion_Main.InputText.text.Length < 3)
            {
                Exclusion_Main.InputText.text += pad_num[1];
            }
        }
        else
        {
            if (Exclusion_Main.InputText.text.Length > 0)
            {
                string del="";
                for(int i = 0; i < Exclusion_Main.InputText.text.Length-1; i++ )
                {
                    del += Exclusion_Main.InputText.text[i];
                }
                Exclusion_Main.InputText.text = del;
            }
        }
        
    }
}