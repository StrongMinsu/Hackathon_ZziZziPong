﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NextBtn : MonoBehaviour
{
    public int index=1;



   public void Next_()
    {
        SoundManager.instance.PlaySound("ArrowBtn", 1f);
   
            if (index == 3)
            GameObject.Find("Canvas").transform.Find("Next_btn").gameObject.SetActive(false);

            GameObject.Find("Canvas").transform.Find("Step" + index.ToString()).gameObject.SetActive(false);
            GameObject.Find("Canvas").transform.Find("Step" + (++index).ToString()).gameObject.SetActive(true);

            if(index == 2)
            GameObject.Find("Canvas").transform.Find("Back_btn").gameObject.SetActive(true);
        

        
    }

    public void Back_()
    {
        SoundManager.instance.PlaySound("ArrowBtn",1f);
            
            if(index == 2)
            { 
                 GameObject.Find("Canvas").transform.Find("Back_btn").gameObject.SetActive(false);
            }
            GameObject.Find("Canvas").transform.Find("Step" + index.ToString()).gameObject.SetActive(false);
            GameObject.Find("Canvas").transform.Find("Step" + (--index).ToString()).gameObject.SetActive(true);

            if(index ==3)
            GameObject.Find("Canvas").transform.Find("Next_btn").gameObject.SetActive(true);

    }
}
