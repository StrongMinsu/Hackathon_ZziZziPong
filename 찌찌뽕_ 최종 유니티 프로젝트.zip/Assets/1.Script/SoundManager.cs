﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{
    public static SoundManager instance;
    public AudioSource audioSource; //실제 재생을 시켜주는 컴포넌트를 여기다 달아줄 것임.
    public List<AudioClip> a_AudioClip = new List<AudioClip>(); // Resource - Sounds 폴더에 있는 오디오 클립들 담을 상자
    private void Awake()
    {
        if (!instance)
        {
            instance = this; //어디서든 쉽게 접근할 수 있도록 싱글톤화
        }
        var obj = FindObjectsOfType<SoundManager>();
        if (obj.Length == 1)
        {
            DontDestroyOnLoad(gameObject); // 중복 검사 후 1개일 때만 지우지 말고
        }
        else
        {
            Destroy(gameObject); // 중복되는 것은 지워라.
        }
    }
    private void Start()
    {
        audioSource = GetComponent<AudioSource>(); // audio를 실제 재생할 수 있는 컴포넌트를 가져옴.
        AudioClips_Load(); //뮤직 리스트 로드
        Title_Manager.instance.Title_Music();
    }
 

    public void AudioClips_Load()
    {

        object[] temp = Resources.LoadAll("Sounds"); //Resources - Sounds 폴더 안에 있는 모든 뮤직리스트 가져옴.

        foreach (var clip in temp)
        {
            a_AudioClip.Add(clip as AudioClip); //가장 맨 위에 선언했던 a_AudioClip리스트에 전부 추가
        }
    }

    public void PlaySound(string clipName, float volume = 1f) //재생할 사운드 이름, 사운드 볼륨
    {                                                                           //볼륨 값은 안넣으면 알아서 최대값인 1로 설정됩니다.
        for (int i = 0; i < a_AudioClip.Count; i++)
        {
            if (a_AudioClip[i].name == clipName)
            {
                audioSource.PlayOneShot(a_AudioClip[i], volume); //뮤직 큐~!
                return; //찾으면 끝냄
            }
        }
    }

    public void PlaySound_Loop(string clipName, float volume = 1f) //재생할 사운드 이름, 사운드 볼륨
    {
        for (int i = 0; i < a_AudioClip.Count; i++)
        {
            if (a_AudioClip[i].name == clipName)
            {
                audioSource.loop = true;
                audioSource.clip = a_AudioClip[i];
                audioSource.volume = volume;
                audioSource.Play();
                return;
            }
        }
    }

    public void AudioStop() //재생 스탑 
    {
        audioSource.Stop();
    }

}